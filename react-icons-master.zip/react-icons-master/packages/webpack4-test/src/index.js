import { FaTimes } from "react-icons/fa";

console.log(FaTimes);
