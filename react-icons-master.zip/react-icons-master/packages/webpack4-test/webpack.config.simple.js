module.exports = {
  mode: "production",
  performance: {
    hints: "error",
    maxEntrypointSize: 100000
  }
};
