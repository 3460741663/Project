# react-icons preview site

## how to develop

```
$ yarn
$ yarn start
```
