# 《JS 正则迷你书》

[JavaScript正则表达式迷你书（1.1版）.pdf](https://github.com/qdlaoyao/js-regex-mini-book/raw/master/JavaScript%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F%E8%BF%B7%E4%BD%A0%E4%B9%A6%EF%BC%881.1%E7%89%88%EF%BC%89.pdf)

[掘金留言](https://juejin.im/post/59cc61176fb9a00a437b290b)
