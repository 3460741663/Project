// this should be the entry point to your library
module.exports = {
  VerticalTimeline: require('./VerticalTimeline').default, // eslint-disable-line global-require
  VerticalTimelineElement: require('./VerticalTimelineElement').default, // eslint-disable-line global-require
};
